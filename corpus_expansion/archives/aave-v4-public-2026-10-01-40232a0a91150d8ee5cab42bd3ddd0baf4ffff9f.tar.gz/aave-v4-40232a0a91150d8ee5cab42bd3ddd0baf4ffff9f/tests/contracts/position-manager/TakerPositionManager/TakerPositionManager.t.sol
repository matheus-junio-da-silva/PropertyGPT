// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import 'tests/contracts/position-manager/TakerPositionManager/TakerPositionManager.Base.t.sol';

contract TakerPositionManagerTest is TakerPositionManagerBaseTest {
  function test_approveWithdraw_fuzz(address spender, uint256 reserveId, uint256 amount) public {
    vm.assume(spender != address(0));
    reserveId = bound(reserveId, 0, spoke1.getReserveCount() - 1);
    amount = bound(amount, 1, MAX_SUPPLY_AMOUNT_DAI);

    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawApproval(address(spoke1), alice, spender, reserveId, amount);
    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), reserveId, spender, amount);

    assertEq(positionManager.withdrawAllowance(address(spoke1), reserveId, alice, spender), amount);
  }

  function test_approveWithdraw_revertsWith_SpokeNotRegistered() public {
    vm.expectRevert(IPositionManagerBase.SpokeNotRegistered.selector);
    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke2), 1, bob, 100e18);
  }

  function test_renounceWithdrawAllowance_fuzz(uint256 initialAllowance) public {
    uint256 reserveId = _randomReserveId(spoke1);
    initialAllowance = bound(initialAllowance, 1, MAX_SUPPLY_AMOUNT_DAI);

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), reserveId, bob, initialAllowance);

    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawApproval(address(spoke1), alice, bob, reserveId, 0);
    vm.prank(bob);
    positionManager.renounceWithdrawAllowance(address(spoke1), reserveId, alice);

    assertEq(positionManager.withdrawAllowance(address(spoke1), reserveId, alice, bob), 0);
  }

  function test_renounceWithdrawAllowance_noop_alreadyRenounced() public {
    uint256 reserveId = _randomReserveId(spoke1);

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), reserveId, bob, 100e18);
    vm.prank(bob);
    positionManager.renounceWithdrawAllowance(address(spoke1), reserveId, alice);

    vm.recordLogs();
    vm.prank(bob);
    positionManager.renounceWithdrawAllowance(address(spoke1), reserveId, alice);
    assertEq(vm.getRecordedLogs().length, 0);
  }

  function test_renounceWithdrawAllowance_revertsWith_SpokeNotRegistered() public {
    vm.expectRevert(IPositionManagerBase.SpokeNotRegistered.selector);
    vm.prank(bob);
    positionManager.renounceWithdrawAllowance(address(spoke2), 1, alice);
  }

  function test_withdrawOnBehalfOf() public {
    test_withdrawOnBehalfOf_fuzz(100e18);
  }

  function test_withdrawOnBehalfOf_fuzz(uint256 amount) public {
    amount = bound(amount, 1, MAX_SUPPLY_AMOUNT_DAI);

    SpokeActions.supply({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: MAX_SUPPLY_AMOUNT_DAI,
      onBehalfOf: alice
    });
    uint256 expectedSupplyShares = hub1.previewAddByAssets(daiAssetId, MAX_SUPPLY_AMOUNT_DAI);

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), _daiReserveId(spoke1), bob, amount);

    uint256 userBalanceBefore = tokenList.dai.balanceOf(alice);
    uint256 callerBalanceBefore = tokenList.dai.balanceOf(bob);
    uint256 hubBalanceBefore = tokenList.dai.balanceOf(address(hub1));
    uint256 userSuppliedAmountBefore = spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice);

    assertEq(spoke1.getUserSuppliedShares(_daiReserveId(spoke1), alice), expectedSupplyShares);

    uint256 expectedShares = hub1.previewRemoveByAssets(daiAssetId, amount);
    uint256 correctedAmount = hub1.previewAddByShares(daiAssetId, expectedShares);
    uint256 expectedAllowance = amount >= correctedAmount ? amount - correctedAmount : 0;

    vm.expectEmit(address(spoke1));
    emit ISpoke.Withdraw(
      _daiReserveId(spoke1),
      address(positionManager),
      alice,
      expectedShares,
      amount
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawApproval(
      address(spoke1),
      alice,
      bob,
      _daiReserveId(spoke1),
      expectedAllowance
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawOnBehalfOf(
      address(spoke1),
      bob,
      alice,
      _daiReserveId(spoke1),
      expectedShares,
      amount
    );
    vm.prank(bob);
    (returnValues.shares, returnValues.amount) = positionManager.withdrawOnBehalfOf(
      address(spoke1),
      _daiReserveId(spoke1),
      amount,
      alice
    );

    assertEq(returnValues.amount, amount);
    assertEq(returnValues.shares, expectedShares);

    assertEq(tokenList.dai.balanceOf(alice), userBalanceBefore);
    assertEq(tokenList.dai.balanceOf(bob), callerBalanceBefore + amount);
    assertEq(
      spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice),
      userSuppliedAmountBefore - amount
    );
    assertEq(tokenList.dai.balanceOf(address(hub1)), hubBalanceBefore - amount);
    assertEq(tokenList.dai.balanceOf(address(positionManager)), 0);
    assertEq(tokenList.dai.allowance(address(positionManager), address(hub1)), 0);
    assertEq(
      positionManager.withdrawAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      expectedAllowance
    );
  }

  function test_withdrawOnBehalfOf_fuzz_allBalance(uint256 supplyAmount) public {
    supplyAmount = bound(supplyAmount, 1, MAX_SUPPLY_AMOUNT_DAI);

    SpokeActions.supply({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: supplyAmount,
      onBehalfOf: alice
    });
    uint256 expectedSupplyShares = hub1.previewAddByAssets(daiAssetId, supplyAmount);

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), _daiReserveId(spoke1), bob, supplyAmount * 10);

    uint256 userBalanceBefore = tokenList.dai.balanceOf(alice);
    uint256 callerBalanceBefore = tokenList.dai.balanceOf(bob);
    uint256 hubBalanceBefore = tokenList.dai.balanceOf(address(hub1));
    uint256 allowanceBefore = positionManager.withdrawAllowance(
      address(spoke1),
      _daiReserveId(spoke1),
      alice,
      bob
    );

    assertEq(spoke1.getUserSuppliedShares(_daiReserveId(spoke1), alice), expectedSupplyShares);

    uint256 correctedAmount = hub1.previewAddByShares(daiAssetId, expectedSupplyShares);
    uint256 expectedAllowance;
    if (allowanceBefore >= correctedAmount) {
      expectedAllowance = allowanceBefore - correctedAmount;
    }

    vm.expectEmit(address(spoke1));
    emit ISpoke.Withdraw(
      _daiReserveId(spoke1),
      address(positionManager),
      alice,
      expectedSupplyShares,
      supplyAmount
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawApproval(
      address(spoke1),
      alice,
      bob,
      _daiReserveId(spoke1),
      expectedAllowance
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawOnBehalfOf(
      address(spoke1),
      bob,
      alice,
      _daiReserveId(spoke1),
      expectedSupplyShares,
      supplyAmount
    );
    vm.prank(bob);
    (returnValues.shares, returnValues.amount) = positionManager.withdrawOnBehalfOf(
      address(spoke1),
      _daiReserveId(spoke1),
      supplyAmount * 2,
      alice
    );

    assertEq(returnValues.amount, supplyAmount);
    assertEq(returnValues.shares, expectedSupplyShares);

    assertEq(tokenList.dai.balanceOf(alice), userBalanceBefore);
    assertEq(tokenList.dai.balanceOf(bob), callerBalanceBefore + supplyAmount);
    assertEq(spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice), 0);
    assertEq(tokenList.dai.balanceOf(address(hub1)), hubBalanceBefore - supplyAmount);
    assertEq(tokenList.dai.balanceOf(address(positionManager)), 0);
    assertEq(tokenList.dai.allowance(address(positionManager), address(hub1)), 0);
    assertEq(
      positionManager.withdrawAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      expectedAllowance
    );
  }

  function test_withdrawOnBehalfOf_fuzz_allBalance_noAllowanceDecreased(
    uint256 supplyAmount
  ) public {
    supplyAmount = bound(supplyAmount, 1, MAX_SUPPLY_AMOUNT_DAI);

    SpokeActions.supply({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: supplyAmount,
      onBehalfOf: alice
    });
    uint256 expectedSupplyShares = hub1.previewAddByAssets(daiAssetId, supplyAmount);

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), _daiReserveId(spoke1), bob, UINT256_MAX);

    uint256 userBalanceBefore = tokenList.dai.balanceOf(alice);
    uint256 callerBalanceBefore = tokenList.dai.balanceOf(bob);
    uint256 hubBalanceBefore = tokenList.dai.balanceOf(address(hub1));

    assertEq(spoke1.getUserSuppliedShares(_daiReserveId(spoke1), alice), expectedSupplyShares);

    vm.expectEmit(address(spoke1));
    emit ISpoke.Withdraw(
      _daiReserveId(spoke1),
      address(positionManager),
      alice,
      expectedSupplyShares,
      supplyAmount
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawOnBehalfOf(
      address(spoke1),
      bob,
      alice,
      _daiReserveId(spoke1),
      expectedSupplyShares,
      supplyAmount
    );
    vm.recordLogs();
    vm.prank(bob);
    (returnValues.shares, returnValues.amount) = positionManager.withdrawOnBehalfOf(
      address(spoke1),
      _daiReserveId(spoke1),
      UINT256_MAX,
      alice
    );
    _assertEventNotEmitted(ITakerPositionManager.WithdrawApproval.selector);

    assertEq(returnValues.amount, supplyAmount);
    assertEq(returnValues.shares, expectedSupplyShares);

    assertEq(tokenList.dai.balanceOf(alice), userBalanceBefore);
    assertEq(tokenList.dai.balanceOf(bob), callerBalanceBefore + supplyAmount);
    assertEq(spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice), 0);
    assertEq(tokenList.dai.balanceOf(address(hub1)), hubBalanceBefore - supplyAmount);
    assertEq(tokenList.dai.balanceOf(address(positionManager)), 0);
    assertEq(tokenList.dai.allowance(address(positionManager), address(hub1)), 0);
    assertEq(
      positionManager.withdrawAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      UINT256_MAX
    );
  }

  function test_withdrawOnBehalfOf_fuzz_allBalanceWithInterest(
    uint256 supplyAmount,
    uint256 borrowAmount
  ) public {
    supplyAmount = bound(supplyAmount, 2, MAX_SUPPLY_AMOUNT_DAI / 2);
    borrowAmount = bound(borrowAmount, 1, supplyAmount / 2);

    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: supplyAmount,
      onBehalfOf: alice
    });
    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: supplyAmount,
      onBehalfOf: bob
    });
    uint256 expectedSupplyShares = hub1.previewAddByAssets(daiAssetId, supplyAmount);

    SpokeActions.borrow({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: borrowAmount,
      onBehalfOf: bob
    });

    skip(322 days);
    vm.assume(hub1.getAddedAssets(daiAssetId) > supplyAmount);
    uint256 repayAmount = spoke1.getReserveTotalDebt(_daiReserveId(spoke1));
    deal(address(tokenList.dai), bob, repayAmount);

    SpokeActions.repay({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: UINT256_MAX,
      onBehalfOf: bob
    });

    uint256 expectedWithdrawAmount = spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice);

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), _daiReserveId(spoke1), bob, supplyAmount * 10);

    uint256 userBalanceBefore = tokenList.dai.balanceOf(alice);
    uint256 callerBalanceBefore = tokenList.dai.balanceOf(bob);
    uint256 hubBalanceBefore = tokenList.dai.balanceOf(address(hub1));
    uint256 suppliedAssetsBefore = spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice);

    assertEq(spoke1.getUserSuppliedShares(_daiReserveId(spoke1), alice), expectedSupplyShares);

    vm.expectEmit(address(spoke1));
    emit ISpoke.Withdraw(
      _daiReserveId(spoke1),
      address(positionManager),
      alice,
      expectedSupplyShares,
      expectedWithdrawAmount
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.WithdrawOnBehalfOf(
      address(spoke1),
      bob,
      alice,
      _daiReserveId(spoke1),
      expectedSupplyShares,
      expectedWithdrawAmount
    );
    vm.recordLogs();
    vm.prank(bob);
    (returnValues.shares, returnValues.amount) = positionManager.withdrawOnBehalfOf(
      address(spoke1),
      _daiReserveId(spoke1),
      supplyAmount * 10,
      alice
    );

    assertEq(returnValues.amount, expectedWithdrawAmount);
    assertEq(returnValues.shares, expectedSupplyShares);

    uint256 correctedWithdrawAmount = suppliedAssetsBefore -
      spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice);
    uint256 expectedAllowance = supplyAmount * 10 - correctedWithdrawAmount;

    _assertWithdrawApprovalEmitted(
      address(spoke1),
      _daiReserveId(spoke1),
      alice,
      bob,
      expectedAllowance
    );

    assertEq(tokenList.dai.balanceOf(alice), userBalanceBefore);
    assertEq(tokenList.dai.balanceOf(bob), callerBalanceBefore + expectedWithdrawAmount);
    assertEq(spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice), 0);
    assertEq(tokenList.dai.balanceOf(address(hub1)), hubBalanceBefore - expectedWithdrawAmount);
    assertEq(tokenList.dai.balanceOf(address(positionManager)), 0);
    assertEq(tokenList.dai.allowance(address(positionManager), address(hub1)), 0);
    assertEq(
      positionManager.withdrawAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      expectedAllowance
    );
  }

  function test_withdrawOnBehalfOf_revertsWith_InsufficientWithdrawAllowance(
    uint256 approvalAmount
  ) public {
    uint256 amount = 100e18;
    approvalAmount = bound(approvalAmount, 1, amount - 1);

    SpokeActions.supply({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: MAX_SUPPLY_AMOUNT_DAI,
      onBehalfOf: alice
    });

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), _daiReserveId(spoke1), bob, approvalAmount);

    vm.expectRevert(
      abi.encodeWithSelector(
        ITakerPositionManager.InsufficientWithdrawAllowance.selector,
        approvalAmount,
        amount
      )
    );
    vm.prank(bob);
    positionManager.withdrawOnBehalfOf(address(spoke1), _daiReserveId(spoke1), amount, alice);
  }

  function test_withdrawOnBehalfOf_revertsWith_ReserveNotListed() public {
    uint256 reserveId = _randomInvalidReserveId(spoke1);

    vm.prank(alice);
    positionManager.approveWithdraw(address(spoke1), reserveId, bob, 100e18);

    vm.expectRevert(ISpoke.ReserveNotListed.selector);
    vm.prank(bob);
    positionManager.withdrawOnBehalfOf(address(spoke1), reserveId, 100e18, alice);
  }

  function test_withdrawOnBehalfOf_revertsWith_SpokeNotRegistered() public {
    vm.expectRevert(IPositionManagerBase.SpokeNotRegistered.selector);
    vm.prank(bob);
    positionManager.withdrawOnBehalfOf(address(spoke2), 1, 100e18, alice);
  }

  function test_approveBorrow_fuzz(address spender, uint256 reserveId, uint256 amount) public {
    vm.assume(spender != address(0));
    reserveId = bound(reserveId, 0, spoke1.getReserveCount() - 1);
    amount = bound(amount, 1, MAX_SUPPLY_AMOUNT_DAI);

    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.BorrowApproval(address(spoke1), alice, spender, reserveId, amount);
    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), reserveId, spender, amount);

    assertEq(positionManager.borrowAllowance(address(spoke1), reserveId, alice, spender), amount);
  }

  function test_approveBorrow_revertsWith_SpokeNotRegistered() public {
    vm.expectRevert(IPositionManagerBase.SpokeNotRegistered.selector);
    vm.prank(alice);
    positionManager.approveBorrow(address(spoke2), 1, bob, 100e18);
  }

  function test_renounceBorrowAllowance_fuzz(uint256 initialAllowance) public {
    uint256 reserveId = _randomReserveId(spoke1);
    initialAllowance = bound(initialAllowance, 1, MAX_SUPPLY_AMOUNT_DAI);

    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), reserveId, bob, initialAllowance);

    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.BorrowApproval(address(spoke1), alice, bob, reserveId, 0);
    vm.prank(bob);
    positionManager.renounceBorrowAllowance(address(spoke1), reserveId, alice);

    assertEq(positionManager.borrowAllowance(address(spoke1), reserveId, alice, bob), 0);
  }

  function test_renounceBorrowAllowance_noop_alreadyRenounced() public {
    uint256 reserveId = _randomReserveId(spoke1);

    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), reserveId, bob, 100e18);
    vm.prank(bob);
    positionManager.renounceBorrowAllowance(address(spoke1), reserveId, alice);

    vm.recordLogs();
    vm.prank(bob);
    positionManager.renounceBorrowAllowance(address(spoke1), reserveId, alice);
    assertEq(vm.getRecordedLogs().length, 0);
  }

  function test_renounceBorrowAllowance_revertsWith_SpokeNotRegistered() public {
    vm.expectRevert(IPositionManagerBase.SpokeNotRegistered.selector);
    vm.prank(bob);
    positionManager.renounceBorrowAllowance(address(spoke2), 1, alice);
  }

  function test_borrowOnBehalfOf() public {
    test_borrowOnBehalfOf_fuzz(5e18, 5e18);
  }

  function test_borrowOnBehalfOf_fuzz(uint256 borrowAmount, uint256 approveBorrowAmount) public {
    uint256 aliceSupplyAmount = 5000e18;
    uint256 bobSupplyAmount = 1000e18;
    borrowAmount = bound(borrowAmount, 1, bobSupplyAmount);
    approveBorrowAmount = bound(approveBorrowAmount, borrowAmount, borrowAmount * 10);

    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: aliceSupplyAmount,
      onBehalfOf: alice
    });
    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: bobSupplyAmount,
      onBehalfOf: bob
    });

    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), _daiReserveId(spoke1), bob, approveBorrowAmount);

    uint256 userBalanceBefore = tokenList.dai.balanceOf(alice);
    uint256 callerBalanceBefore = tokenList.dai.balanceOf(bob);
    uint256 hubBalanceBefore = tokenList.dai.balanceOf(address(hub1));

    uint256 expectedBorrowShares = hub1.previewDrawByAssets(daiAssetId, borrowAmount);

    uint256 totalDebtBefore = spoke1.getUserTotalDebt(_daiReserveId(spoke1), alice);

    vm.expectEmit(address(spoke1));
    emit ISpoke.Borrow(
      _daiReserveId(spoke1),
      address(positionManager),
      alice,
      expectedBorrowShares,
      borrowAmount
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.BorrowOnBehalfOf(
      address(spoke1),
      bob,
      alice,
      _daiReserveId(spoke1),
      expectedBorrowShares,
      borrowAmount
    );
    vm.recordLogs();
    vm.prank(bob);
    (returnValues.shares, returnValues.amount) = positionManager.borrowOnBehalfOf(
      address(spoke1),
      _daiReserveId(spoke1),
      borrowAmount,
      alice
    );

    uint256 totalDebtAfter = spoke1.getUserTotalDebt(_daiReserveId(spoke1), alice);

    uint256 correctedBorrowAmount = totalDebtAfter - totalDebtBefore;
    uint256 expectedBorrowAllowance;
    if (approveBorrowAmount >= correctedBorrowAmount) {
      expectedBorrowAllowance = approveBorrowAmount - correctedBorrowAmount;
    }

    _assertBorrowApprovalEmitted(
      address(spoke1),
      _daiReserveId(spoke1),
      alice,
      bob,
      expectedBorrowAllowance
    );

    assertEq(returnValues.amount, borrowAmount);
    assertEq(returnValues.shares, expectedBorrowShares);

    assertEq(spoke1.getUserTotalDebt(_daiReserveId(spoke1), alice), borrowAmount);
    assertEq(tokenList.dai.balanceOf(address(hub1)), hubBalanceBefore - borrowAmount);
    assertEq(tokenList.dai.balanceOf(address(alice)), userBalanceBefore);
    assertEq(tokenList.dai.balanceOf(address(bob)), callerBalanceBefore + borrowAmount);
    assertEq(tokenList.dai.allowance(address(positionManager), address(hub1)), 0);
    assertEq(
      positionManager.borrowAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      expectedBorrowAllowance
    );
  }

  function test_borrowOnBehalfOf_fuzz_withInterest(
    uint256 supplyAmount,
    uint256 initialBorrowAmount,
    uint256 borrowAmount
  ) public {
    supplyAmount = bound(supplyAmount, 2, MAX_SUPPLY_AMOUNT_DAI / 2);
    initialBorrowAmount = bound(initialBorrowAmount, 1, supplyAmount / 2);

    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: supplyAmount,
      onBehalfOf: alice
    });
    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: supplyAmount,
      onBehalfOf: bob
    });

    SpokeActions.borrow({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: initialBorrowAmount,
      onBehalfOf: bob
    });

    skip(322 days);

    uint256 availableLiquidity = tokenList.dai.balanceOf(address(hub1));
    uint256 maxBorrow = spoke1.getUserSuppliedAssets(_daiReserveId(spoke1), alice) / 10;
    if (availableLiquidity / 2 < maxBorrow) maxBorrow = availableLiquidity / 2;
    vm.assume(maxBorrow > 0);
    borrowAmount = bound(borrowAmount, 1, maxBorrow);

    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), _daiReserveId(spoke1), bob, borrowAmount * 10);

    uint256 totalDebtBefore = spoke1.getUserTotalDebt(_daiReserveId(spoke1), alice);
    uint256 userBalanceBefore = tokenList.dai.balanceOf(alice);
    uint256 callerBalanceBefore = tokenList.dai.balanceOf(bob);

    uint256 expectedBorrowShares = hub1.previewDrawByAssets(daiAssetId, borrowAmount);

    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.BorrowOnBehalfOf(
      address(spoke1),
      bob,
      alice,
      _daiReserveId(spoke1),
      expectedBorrowShares,
      borrowAmount
    );
    vm.recordLogs();
    vm.prank(bob);
    (returnValues.shares, returnValues.amount) = positionManager.borrowOnBehalfOf(
      address(spoke1),
      _daiReserveId(spoke1),
      borrowAmount,
      alice
    );

    uint256 totalDebtAfter = spoke1.getUserTotalDebt(_daiReserveId(spoke1), alice);
    uint256 correctedBorrowAmount = totalDebtAfter - totalDebtBefore;
    uint256 expectedBorrowAllowance = borrowAmount * 10 - correctedBorrowAmount;

    _assertBorrowApprovalEmitted(
      address(spoke1),
      _daiReserveId(spoke1),
      alice,
      bob,
      expectedBorrowAllowance
    );

    assertEq(returnValues.amount, borrowAmount);
    assertEq(tokenList.dai.balanceOf(alice), userBalanceBefore);
    assertEq(tokenList.dai.balanceOf(bob), callerBalanceBefore + borrowAmount);
    assertEq(
      positionManager.borrowAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      expectedBorrowAllowance
    );
  }

  function test_borrowOnBehalfOf_fuzz_noAllowanceDecrease(uint256 borrowAmount) public {
    uint256 aliceSupplyAmount = 5000e18;
    uint256 bobSupplyAmount = 1000e18;
    borrowAmount = bound(borrowAmount, 1, bobSupplyAmount);

    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: aliceSupplyAmount,
      onBehalfOf: alice
    });
    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: bobSupplyAmount,
      onBehalfOf: bob
    });

    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), _daiReserveId(spoke1), bob, UINT256_MAX);

    uint256 userBalanceBefore = tokenList.dai.balanceOf(alice);
    uint256 callerBalanceBefore = tokenList.dai.balanceOf(bob);
    uint256 hubBalanceBefore = tokenList.dai.balanceOf(address(hub1));

    vm.expectEmit(address(spoke1));
    emit ISpoke.Borrow(
      _daiReserveId(spoke1),
      address(positionManager),
      alice,
      hub1.previewRestoreByAssets(daiAssetId, borrowAmount),
      borrowAmount
    );
    vm.expectEmit(address(positionManager));
    emit ITakerPositionManager.BorrowOnBehalfOf(
      address(spoke1),
      bob,
      alice,
      _daiReserveId(spoke1),
      hub1.previewDrawByAssets(daiAssetId, borrowAmount),
      borrowAmount
    );
    vm.recordLogs();
    vm.prank(bob);
    (returnValues.shares, returnValues.amount) = positionManager.borrowOnBehalfOf(
      address(spoke1),
      _daiReserveId(spoke1),
      borrowAmount,
      alice
    );
    _assertEventNotEmitted(ITakerPositionManager.BorrowApproval.selector);

    (uint256 userDrawnDebt, uint256 userPremiumDebt) = spoke1.getUserDebt(
      _daiReserveId(spoke1),
      alice
    );

    assertEq(returnValues.amount, borrowAmount);
    assertEq(returnValues.shares, hub1.previewDrawByAssets(daiAssetId, borrowAmount));

    assertEq(userDrawnDebt + userPremiumDebt, borrowAmount);
    assertEq(tokenList.dai.balanceOf(address(hub1)), hubBalanceBefore - borrowAmount);
    assertEq(tokenList.dai.balanceOf(address(alice)), userBalanceBefore);
    assertEq(tokenList.dai.balanceOf(address(bob)), callerBalanceBefore + borrowAmount);
    assertEq(tokenList.dai.allowance(address(positionManager), address(hub1)), 0);
    assertEq(
      positionManager.borrowAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      UINT256_MAX
    );
  }

  function test_borrowOnBehalfOf_revertsWith_InsufficientBorrowAllowance(
    uint256 approveBorrowAmount
  ) public {
    uint256 borrowAmount = 100e18;
    approveBorrowAmount = bound(approveBorrowAmount, 1, borrowAmount - 1);
    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: alice,
      amount: borrowAmount,
      onBehalfOf: alice
    });
    SpokeActions.supplyCollateral({
      spoke: spoke1,
      reserveId: _daiReserveId(spoke1),
      caller: bob,
      amount: borrowAmount,
      onBehalfOf: bob
    });

    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), _daiReserveId(spoke1), bob, approveBorrowAmount);

    vm.expectRevert(
      abi.encodeWithSelector(
        ITakerPositionManager.InsufficientBorrowAllowance.selector,
        approveBorrowAmount,
        borrowAmount
      )
    );
    vm.prank(bob);
    positionManager.borrowOnBehalfOf(address(spoke1), _daiReserveId(spoke1), borrowAmount, alice);
  }

  function test_borrowOnBehalfOf_revertsWith_ReserveNotListed() public {
    uint256 reserveId = _randomInvalidReserveId(spoke1);

    vm.prank(alice);
    positionManager.approveBorrow(address(spoke1), reserveId, bob, 100e18);

    vm.expectRevert(ISpoke.ReserveNotListed.selector);
    vm.prank(bob);
    positionManager.borrowOnBehalfOf(address(spoke1), reserveId, 100e18, alice);
  }

  function test_borrowOnBehalfOf_revertsWith_SpokeNotRegistered() public {
    vm.expectRevert(IPositionManagerBase.SpokeNotRegistered.selector);
    vm.prank(bob);
    positionManager.borrowOnBehalfOf(address(spoke2), 1, 100e18, alice);
  }

  function _assertWithdrawApprovalEmitted(
    address spoke,
    uint256 reserveId,
    address owner,
    address spender,
    uint256 amount
  ) internal {
    Vm.Log[] memory entries = vm.getRecordedLogs();
    bytes32 sig = ITakerPositionManager.WithdrawApproval.selector;
    for (uint256 i; i < entries.length; ++i) {
      if (
        entries[i].topics[0] == sig &&
        entries[i].topics[1] == bytes32(uint256(uint160(spoke))) &&
        entries[i].topics[2] == bytes32(uint256(uint160(owner))) &&
        entries[i].topics[3] == bytes32(uint256(uint160(spender)))
      ) {
        (uint256 logReserveId, uint256 logAmount) = abi.decode(entries[i].data, (uint256, uint256));
        assertEq(logReserveId, reserveId);
        assertEq(logAmount, amount);
        return;
      }
    }
    revert('WithdrawApproval event not emitted');
  }

  function _assertBorrowApprovalEmitted(
    address spoke,
    uint256 reserveId,
    address owner,
    address spender,
    uint256 amount
  ) internal {
    Vm.Log[] memory entries = vm.getRecordedLogs();
    bytes32 sig = ITakerPositionManager.BorrowApproval.selector;
    for (uint256 i; i < entries.length; ++i) {
      if (
        entries[i].topics[0] == sig &&
        entries[i].topics[1] == bytes32(uint256(uint160(spoke))) &&
        entries[i].topics[2] == bytes32(uint256(uint160(owner))) &&
        entries[i].topics[3] == bytes32(uint256(uint160(spender)))
      ) {
        (uint256 logReserveId, uint256 logAmount) = abi.decode(entries[i].data, (uint256, uint256));
        assertEq(logReserveId, reserveId);
        assertEq(logAmount, amount);
        return;
      }
    }
    revert('BorrowApproval event not emitted');
  }

  function test_multicall() public {
    uint256 amount = 100e18;

    bytes[] memory calls = new bytes[](2);
    calls[0] = abi.encodeWithSignature(
      'approveWithdraw(address,uint256,address,uint256)',
      address(spoke1),
      _daiReserveId(spoke1),
      bob,
      amount
    );
    calls[1] = abi.encodeWithSignature(
      'approveBorrow(address,uint256,address,uint256)',
      address(spoke1),
      _daiReserveId(spoke1),
      bob,
      amount
    );

    vm.prank(alice);
    bytes[] memory res = positionManager.multicall(calls);

    assertEq(res[0].length, 0);
    assertEq(res[1].length, 0);

    assertEq(
      positionManager.withdrawAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      amount
    );
    assertEq(
      positionManager.borrowAllowance(address(spoke1), _daiReserveId(spoke1), alice, bob),
      amount
    );
  }
}
