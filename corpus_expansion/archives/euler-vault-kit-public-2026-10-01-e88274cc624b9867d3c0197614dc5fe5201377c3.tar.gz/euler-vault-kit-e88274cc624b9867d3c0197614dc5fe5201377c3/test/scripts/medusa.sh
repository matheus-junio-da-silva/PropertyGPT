#!/bin/bash

medusa fuzz