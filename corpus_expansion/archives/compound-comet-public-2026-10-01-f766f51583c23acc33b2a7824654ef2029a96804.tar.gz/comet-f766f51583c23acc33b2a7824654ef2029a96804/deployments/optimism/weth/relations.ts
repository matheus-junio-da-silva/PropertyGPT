import baseRelationConfig from '../../relations';

export default {
  ...baseRelationConfig,
  governor: {
    artifact:
      'contracts/bridges/optimism/OptimismBridgeReceiver.sol:OptimismBridgeReceiver',
  },
  Proxy: {
    artifact: 'contracts/interfaces/ERC20.sol:ERC20',
  },

  l2CrossDomainMessenger: {
    delegates: {
      field: {
        slot:
          '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc',
      },
    },
  },

  l2StandardBridge: {
    delegates: {
      field: {
        slot:
          '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc',
      },
    },
  },

  // rETH
  L2StandardERC20: {
    artifact: 'contracts/interfaces/ERC20.sol:ERC20'
  },

  // wstETH
  OssifiableProxy: {
    artifact: 'contracts/interfaces/ERC20.sol:ERC20',
    delegates: {
      field: {
        slot: '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc'
      }
    }
  },

  TransparentUpgradeableProxy: {
    artifact: 'contracts/interfaces/ERC20.sol:ERC20',
    delegates: {
      field: {
        slot: '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc'
      }
    }
  },

  // WBTC
  WBTC: {
    artifact: 'contracts/interfaces/ERC20.sol:ERC20'
  },
};
